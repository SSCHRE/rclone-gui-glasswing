const operationHints = {

  copy: "Copy adds or updates files in the destination.",

  sync: "Sync makes the destination match the source. Destructive on the destination side.",

  move: "Move transfers files and deletes them from the source when done.",

  bisync: "Bisync keeps both sides in step: new, changed and deleted files on either side are applied to the other.",

};



const elements = {

  version: document.getElementById("rclone-version"),
  appVersion: document.getElementById("app-version"),

  operation: document.getElementById("operation"),

  operationHint: document.getElementById("operation-hint"),

  source: document.getElementById("source"),

  destination: document.getElementById("destination"),

  remotePicker: document.getElementById("remote-picker"),

  remotePath: document.getElementById("remote-path"),

  dryRun: document.getElementById("dry-run"),

  deleteExcluded: document.getElementById("delete-excluded"),
  resync: document.getElementById("resync"),
  resyncOption: document.getElementById("resync-option"),
  extraArgs: document.getElementById("extra-args"),

  runJob: document.getElementById("run-job"),

  stopJob: document.getElementById("stop-job"),

  refreshRemotes: document.getElementById("refresh-remotes"),
  manageRemotes: document.getElementById("manage-remotes"),
  checkForUpdates: document.getElementById("check-for-updates"),
  modeJobs: document.getElementById("mode-jobs"),
  modeBrowse: document.getElementById("mode-browse"),
  modeStorage: document.getElementById("mode-storage"),
  modeHistory: document.getElementById("mode-history"),
  jobsView: document.getElementById("jobs-view"),
  browseView: document.getElementById("browse-view"),

  status: document.getElementById("status"),
  popupRoot: document.getElementById("popup-root"),
  popupCard: document.querySelector("#popup-root .popup-card"),
  popupTitle: document.getElementById("popup-title"),
  popupMessage: document.getElementById("popup-message"),
  popupClose: document.getElementById("popup-close"),
  updateDialog: document.getElementById("update-dialog"),
  updateCurrent: document.getElementById("update-current"),
  updateLatest: document.getElementById("update-latest"),
  updateDate: document.getElementById("update-date"),
  updateLater: document.getElementById("update-later"),
  updateSkip: document.getElementById("update-skip"),
  updateDot: document.getElementById("update-dot"),
  updateOpen: document.getElementById("update-open"),
  updateTitle: document.getElementById("update-title"),
  updateProgress: document.getElementById("update-progress"),
  updateProgressBar: document.querySelector("#update-progress .migration-progress"),
  updateProgressFill: document.getElementById("update-progress-fill"),
  updateProgressText: document.getElementById("update-progress-text"),
  updateHint: document.getElementById("update-hint"),
  updateError: document.getElementById("update-error"),
  updateNotes: document.getElementById("update-notes"),
  rcloneUpdateDialog: document.getElementById("rclone-update-dialog"),
  rcloneUpdateCurrent: document.getElementById("rclone-update-current"),
  rcloneUpdateLatest: document.getElementById("rclone-update-latest"),
  rcloneUpdateNote: document.getElementById("rclone-update-note"),
  rcloneUpdateError: document.getElementById("rclone-update-error"),
  rcloneUpdateSkip: document.getElementById("rclone-update-skip"),
  rcloneUpdateLater: document.getElementById("rclone-update-later"),
  rcloneUpdateGo: document.getElementById("rclone-update-go"),
  jobHistoryPicker: document.getElementById("job-history-picker"),
  loadJob: document.getElementById("load-job"),
  updateJob: document.getElementById("update-job"),
  saveJob: document.getElementById("save-job"),
  deleteJob: document.getElementById("delete-job"),
  scheduleJob: document.getElementById("schedule-job"),
  jobHistoryMeta: document.getElementById("job-history-meta"),
  jobHistoryCollapsible: document.getElementById("job-history-collapsible"),
  remoteInsertCollapsible: document.getElementById("remote-insert-collapsible"),
  jobHistoryCount: document.getElementById("job-history-count"),
  saveJobDialog: document.getElementById("save-job-dialog"),
  saveJobName: document.getElementById("save-job-name"),
  saveJobConfirm: document.getElementById("save-job-confirm"),
  saveJobCancel: document.getElementById("save-job-cancel"),
  snackbarRoot: document.getElementById("snackbar-root"),
  snackbar: document.getElementById("snackbar"),
  snackbarIcon: document.getElementById("snackbar-icon"),
  snackbarTitle: document.getElementById("snackbar-title"),
  snackbarMessage: document.getElementById("snackbar-message"),
};

const outputPanel = new JobOutputPanel(document.querySelector(".output-panel"));

let activeJobId = null;
let jobRunning = false;
let remotes = [];
let jobHistory = [];
let statusHideTimeout = null;
let statusFadeTimeout = null;
let popupHideTimeout = null;
let snackbarHideTimeout = null;
let snackbarLeaveTimeout = null;
const STATUS_FADE_MS = 450;
const POPUP_AUTO_CLOSE_MS = 3500;
const SNACKBAR_DURATION_MS = 3400;
const SNACKBAR_LEAVE_MS = 220;

function hideSnackbar() {
  if (snackbarHideTimeout) {
    clearTimeout(snackbarHideTimeout);
    snackbarHideTimeout = null;
  }

  if (snackbarLeaveTimeout) {
    clearTimeout(snackbarLeaveTimeout);
    snackbarLeaveTimeout = null;
  }

  elements.snackbar.classList.remove("success", "error", "running", "is-leaving");
  elements.snackbarIcon.textContent = "";
  elements.snackbarTitle.textContent = "";
  elements.snackbarMessage.textContent = "";
  elements.snackbarRoot.classList.add("hidden");
  elements.snackbarRoot.setAttribute("aria-hidden", "true");
}

function snackbarMessageNodes(message) {
  const parts = Array.isArray(message) ? message : [message];
  return parts.map((part) => {
    if (part && typeof part === "object") {
      const strong = document.createElement("strong");
      strong.textContent = String(part.strong ?? "");
      return strong;
    }
    return String(part ?? "");
  });
}

function showSnackbar({ title, message, type = "success" }) {
  hideSnackbar();
  void elements.snackbar.offsetWidth;

  elements.snackbarTitle.textContent = title;
  elements.snackbarMessage.replaceChildren(...snackbarMessageNodes(message));
  elements.snackbar.classList.add(type);
  elements.snackbarRoot.classList.remove("hidden");
  elements.snackbarRoot.setAttribute("aria-hidden", "false");

  snackbarHideTimeout = setTimeout(() => {
    elements.snackbar.classList.add("is-leaving");
    snackbarLeaveTimeout = setTimeout(hideSnackbar, SNACKBAR_LEAVE_MS);
    snackbarHideTimeout = null;
  }, SNACKBAR_DURATION_MS);
}

function hidePopup() {
  if (popupHideTimeout) {
    clearTimeout(popupHideTimeout);
    popupHideTimeout = null;
  }

  elements.popupRoot.classList.add("hidden");
  elements.popupRoot.setAttribute("aria-hidden", "true");
  elements.popupCard.classList.remove("success", "error");
}

function showPopup({ title, message, type = "success", autoClose = true }) {
  hidePopup();

  elements.popupTitle.textContent = title;
  elements.popupMessage.textContent = message;
  elements.popupCard.classList.add(type);
  elements.popupRoot.classList.remove("hidden");
  elements.popupRoot.setAttribute("aria-hidden", "false");
  elements.popupClose.focus();

  if (autoClose) {
    popupHideTimeout = setTimeout(hidePopup, POPUP_AUTO_CLOSE_MS);
  }
}

function clearStatusTimeouts() {
  if (statusHideTimeout) {
    clearTimeout(statusHideTimeout);
    statusHideTimeout = null;
  }

  if (statusFadeTimeout) {
    clearTimeout(statusFadeTimeout);
    statusFadeTimeout = null;
  }
}

function ensureStatusVisible() {
  if (!elements.status?.textContent) {
    return;
  }

  elements.status.scrollIntoView({ block: "nearest", behavior: "smooth" });
}

function setStatus(text, tone = "", options = {}) {
  clearStatusTimeouts();
  elements.status.classList.remove("is-fading-out");
  elements.status.textContent = text;
  elements.status.className = `status ${tone}`.trim();

  if (text && options.ensureVisible) {
    requestAnimationFrame(() => ensureStatusVisible());
  }

  if (options.hideAfter) {
    statusHideTimeout = setTimeout(() => {
      elements.status.classList.add("is-fading-out");
      statusFadeTimeout = setTimeout(() => {
        elements.status.textContent = "";
        elements.status.className = "status";
        statusFadeTimeout = null;
      }, STATUS_FADE_MS);
      statusHideTimeout = null;
    }, options.hideAfter);
  }
}



function setRunning(isRunning) {
  jobRunning = isRunning;
  window.RunHistory?.syncLoadButtons();
  elements.runJob.disabled = isRunning;
  elements.stopJob.disabled = !isRunning;
  elements.operation.disabled = isRunning;
  elements.source.disabled = isRunning;
  elements.destination.disabled = isRunning;
  elements.dryRun.disabled = isRunning;
  elements.deleteExcluded.disabled = isRunning || elements.operation.value !== "sync";
  elements.resync.disabled = isRunning;
  elements.extraArgs.disabled = isRunning;
  elements.jobHistoryPicker.disabled = isRunning;
  elements.loadJob.disabled = isRunning || !elements.jobHistoryPicker.value;
  elements.updateJob.disabled = isRunning || !elements.jobHistoryPicker.value;
  elements.saveJob.disabled = isRunning;
  elements.deleteJob.disabled = isRunning || !elements.jobHistoryPicker.value;
  elements.scheduleJob.disabled = isRunning || !elements.jobHistoryPicker.value;
  if (elements.manageRemotes) {
    elements.manageRemotes.disabled = isRunning;
  }
}

function getCurrentJobConfig() {
  return {
    operation: elements.operation.value,
    source: elements.source.value.trim(),
    destination: elements.destination.value.trim(),
    dryRun: elements.dryRun.checked,
    deleteExcluded: elements.deleteExcluded.checked,
    resync: elements.operation.value === "bisync" && elements.resync.checked,
    extraArgs: elements.extraArgs.value.trim(),
  };
}

function formatRelativeTime(timestamp) {
  if (!timestamp) {
    return "never run";
  }

  const deltaMs = Date.now() - timestamp;
  const minutes = Math.floor(deltaMs / 60000);
  if (minutes < 1) {
    return "just now";
  }
  if (minutes < 60) {
    return `${minutes}m ago`;
  }

  const hours = Math.floor(minutes / 60);
  if (hours < 48) {
    return `${hours}h ago`;
  }

  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

function formatJobOptionLabel(entry) {
  return entry.schedule?.enabled ? `⏰ ${entry.name}` : entry.name;
}

function formatJobMeta(entry) {
  if (!entry) {
    return "";
  }

  const parts = [
    `${entry.operation} · ${entry.source} → ${entry.destination}`,
  ];

  if (entry.schedule?.enabled) {
    const next = entry.schedule.nextRunAt
      ? `, next run ${window.JobSchedule.formatNextRun(entry.schedule.nextRunAt)}`
      : "";
    parts.push(`⏰ ${entry.schedule.description || "Scheduled"}${next}`);
  }

  parts.push(`Last run ${formatRelativeTime(entry.lastRunAt)}`);

  if (entry.runCount > 0) {
    parts.push(`${entry.runCount} run${entry.runCount === 1 ? "" : "s"}`);
  }

  if (entry.lastRunSuccess === true) {
    parts.push("last: success");
  } else if (entry.lastRunSuccess === false) {
    parts.push("last: failed");
  }

  if (entry.dryRun) {
    parts.push("dry run");
  }

  if (entry.deleteExcluded) {
    parts.push("delete excluded");
  }

  if (entry.extraArgs) {
    const preview = entry.extraArgs.length > 48
      ? `${entry.extraArgs.slice(0, 47)}…`
      : entry.extraArgs;
    parts.push(`flags: ${preview}`);
  }

  return parts.join(" · ");
}

function getSelectedHistoryEntry() {
  const selectedId = elements.jobHistoryPicker.value;
  if (!selectedId) {
    return null;
  }

  return jobHistory.find((entry) => entry.id === selectedId) || null;
}

function savedJobMatchesForm(entry) {
  if (!entry) {
    return false;
  }

  const job = getCurrentJobConfig();
  return (
    entry.operation === job.operation &&
    entry.source === job.source &&
    entry.destination === job.destination &&
    entry.dryRun === job.dryRun &&
    entry.deleteExcluded === job.deleteExcluded &&
    (entry.extraArgs || "") === job.extraArgs
  );
}

function applyJobToForm(entry, { fromSavedJob = false } = {}) {
  elements.operation.value = entry.operation;
  elements.source.value = entry.source;
  elements.destination.value = entry.destination;
  elements.dryRun.checked = entry.dryRun;
  elements.deleteExcluded.checked = entry.deleteExcluded;
  elements.resync.checked = false;
  elements.extraArgs.value = entry.extraArgs || "";
  elements.operation.dispatchEvent(new Event("change"));
  updatePathMeters({ immediate: true });

  if (fromSavedJob) {
    elements.remoteInsertCollapsible.open = false;
  }
}

function updateHistoryActions() {
  const entry = getSelectedHistoryEntry();
  const hasSelection = Boolean(entry);
  const isRunning = activeJobId !== null;

  elements.loadJob.disabled = isRunning || !hasSelection;
  elements.updateJob.disabled = isRunning || !hasSelection || savedJobMatchesForm(entry);
  elements.deleteJob.disabled = isRunning || !hasSelection;
  elements.scheduleJob.disabled = isRunning || !hasSelection;
  elements.jobHistoryMeta.textContent = entry ? formatJobMeta(entry) : "";
}

function updateJobHistoryCount() {
  if (jobHistory.length === 0) {
    elements.jobHistoryCount.textContent = "";
    return;
  }

  const scheduled = jobHistory.filter((entry) => entry.schedule?.enabled).length;
  elements.jobHistoryCount.textContent = `${jobHistory.length} job${jobHistory.length === 1 ? "" : "s"}${scheduled ? ` · ${scheduled} scheduled` : ""}`;
}

function fillJobHistoryPicker(selectedId = "") {
  const current = selectedId || elements.jobHistoryPicker.value;
  elements.jobHistoryPicker.innerHTML = '<option value="">Select a job to load…</option>';

  for (const entry of jobHistory) {
    const option = document.createElement("option");
    option.value = entry.id;
    option.textContent = formatJobOptionLabel(entry);
    elements.jobHistoryPicker.appendChild(option);
  }

  if (jobHistory.some((entry) => entry.id === current)) {
    elements.jobHistoryPicker.value = current;
  }

  updateJobHistoryCount();
  updateHistoryActions();
}

async function refreshJobHistory(selectedId = "") {
  jobHistory = await window.rcloneGui.listJobs();
  fillJobHistoryPicker(selectedId);
}

const runWarnings = {
  sync: "Files in the destination that aren't in the source will be deleted.",
  move: "Files are deleted from the source after they're transferred.",
  bisync: "Changes and deletions on either side are applied to the other side.",
};

function confirmRunCommand(job, command) {
  const dialog = document.getElementById("run-confirm-dialog");
  const message = document.getElementById("run-confirm-message");
  const commandBlock = document.getElementById("run-confirm-command");
  const copyBtn = document.getElementById("run-confirm-copy");
  const cancelBtn = document.getElementById("run-confirm-cancel");
  const startBtn = document.getElementById("run-confirm-start");
  const remember = document.getElementById("run-confirm-remember");
  const backdrop = dialog.querySelector("[data-run-confirm-close]");

  message.textContent = job.dryRun
    ? "Dry run: rclone will only report what it would do. Nothing will be changed."
    : runWarnings[job.operation] || "This is the exact command Glasswing will run.";
  commandBlock.textContent = command;
  copyBtn.textContent = "Copy command";
  remember.checked = false;
  dialog.classList.remove("hidden");
  dialog.setAttribute("aria-hidden", "false");
  startBtn.focus();

  return new Promise((resolve) => {
    const finish = (confirmed) => {
      dialog.classList.add("hidden");
      dialog.setAttribute("aria-hidden", "true");
      startBtn.removeEventListener("click", onStart);
      cancelBtn.removeEventListener("click", onCancel);
      backdrop.removeEventListener("click", onCancel);
      copyBtn.removeEventListener("click", onCopy);
      document.removeEventListener("keydown", onKeydown, true);
      resolve({ confirmed, remember: confirmed && remember.checked });
    };
    const onStart = () => finish(true);
    const onCancel = () => finish(false);
    const onCopy = async () => {
      try {
        await navigator.clipboard.writeText(command);
        copyBtn.textContent = "Copied";
      } catch {
        copyBtn.textContent = "Copy failed";
      }
    };
    const onKeydown = (event) => {
      if (event.key === "Escape") {
        event.stopPropagation();
        finish(false);
      }
    };

    startBtn.addEventListener("click", onStart);
    cancelBtn.addEventListener("click", onCancel);
    backdrop.addEventListener("click", onCancel);
    copyBtn.addEventListener("click", onCopy);
    document.addEventListener("keydown", onKeydown, true);
  });
}

function hideSaveJobDialog() {
  elements.saveJobDialog.classList.add("hidden");
  elements.saveJobDialog.setAttribute("aria-hidden", "true");
  elements.saveJobName.value = "";
}

function showSaveJobDialog() {
  const job = getCurrentJobConfig();
  if (!job.source || !job.destination) {
    setStatus("Source and destination are required before saving.", "error");
    return;
  }

  elements.saveJobName.value = "";
  elements.saveJobDialog.classList.remove("hidden");
  elements.saveJobDialog.setAttribute("aria-hidden", "false");
  elements.saveJobName.focus();
}

async function confirmSaveJob() {
  const job = getCurrentJobConfig();
  if (!job.source || !job.destination) {
    setStatus("Source and destination are required before saving.", "error");
    return;
  }

  try {
    jobHistory = await window.rcloneGui.saveJob({
      ...job,
      name: elements.saveJobName.value.trim(),
    });
    hideSaveJobDialog();

    const savedEntry = jobHistory.find(
      (entry) =>
        entry.operation === job.operation &&
        entry.source === job.source &&
        entry.destination === job.destination &&
        entry.dryRun === job.dryRun &&
        entry.deleteExcluded === job.deleteExcluded &&
        (entry.extraArgs || "") === job.extraArgs,
    );

    fillJobHistoryPicker(savedEntry?.id || "");
    setStatus("Job saved for quick access.", "success", { hideAfter: 4000, ensureVisible: true });
    showPopup({
      title: "Job saved",
      message: "You can load or update it anytime from Saved jobs.",
      type: "success",
    });
  } catch (error) {
    setStatus(error.message, "error");
  }
}

async function startJobFromForm() {
  const job = getCurrentJobConfig();

  if (!job.source || !job.destination) {
    setStatus("Source and destination are required.", "error");
    return;
  }

  let preview;
  try {
    preview = await window.rcloneGui.previewJobCommand(job);
  } catch (error) {
    setStatus(String(error.message || "").replace(/^Error invoking remote method '[^']+': (?:Error: )?/, ""), "error");
    return;
  }

  if (!preview.approved) {
    const choice = await confirmRunCommand(job, preview.command);
    if (!choice.confirmed) {
      return;
    }
    if (choice.remember) {
      await window.rcloneGui.approveJobCommand(job).catch(() => {});
    }
  }

  setRunning(true);

  try {
    const result = await window.rcloneGui.startJob(job);
    activeJobId = result.id;

    outputPanel.startJob({
      operation: job.operation,
      source: job.source,
      destination: job.destination,
    });

    showSnackbar({
      title: "Job running",
      message: `${job.operation.charAt(0).toUpperCase() + job.operation.slice(1)} job started.`,
      type: "running",
    });
    await refreshJobHistory(elements.jobHistoryPicker.value);
  } catch (error) {
    setRunning(false);
    setStatus(error.message, "error");
  }
}



function trimSlashes(value) {
  let start = 0;
  let end = value.length;
  while (start < end && value[start] === "/") {
    start += 1;
  }
  while (end > start && value[end - 1] === "/") {
    end -= 1;
  }
  return value.slice(start, end);
}

function formatRemotePath(remote, subPath) {

  const trimmedPath = trimSlashes(subPath.trim());

  return trimmedPath ? `${remote}:${trimmedPath}` : `${remote}:`;

}



function fillRemotePicker() {

  const current = elements.remotePicker.value;

  elements.remotePicker.innerHTML = '<option value="">Select a configured remote...</option>';



  for (const remote of remotes) {

    const option = document.createElement("option");

    option.value = remote;

    option.textContent = remote;

    elements.remotePicker.appendChild(option);

  }



  if (remotes.includes(current)) {

    elements.remotePicker.value = current;

  }

}



function measureRequiredContentSize() {
  const app = document.querySelector(".app");
  const layout =
    document.querySelector(".layout:not(.hidden)") || document.querySelector(".layout");
  if (!app || !layout) {
    return null;
  }

  const panels = [...layout.querySelectorAll(":scope > .panel")];
  const savedStyles = [
    { element: app, minHeight: app.style.minHeight, height: app.style.height, flex: app.style.flex },
    { element: layout, minHeight: layout.style.minHeight, height: layout.style.height, flex: layout.style.flex },
    ...panels.map((panel) => ({
      element: panel,
      minHeight: panel.style.minHeight,
      height: panel.style.height,
      flex: panel.style.flex,
    })),
  ];

  app.style.minHeight = "0";
  app.style.height = "auto";
  app.style.flex = "0 0 auto";
  layout.style.minHeight = "0";
  layout.style.height = "auto";
  layout.style.flex = "0 0 auto";
  for (const panel of panels) {
    panel.style.minHeight = "0";
    panel.style.height = "auto";
  }

  void app.offsetHeight;

  const appTop = app.getBoundingClientRect().top;
  const paddingBottom = Number.parseFloat(getComputedStyle(app).paddingBottom) || 0;
  let contentBottom = layout.getBoundingClientRect().bottom - appTop;

  if (elements.status?.textContent) {
    contentBottom = Math.max(
      contentBottom,
      elements.status.getBoundingClientRect().bottom - appTop,
    );
  }

  for (const { element, minHeight, height, flex } of savedStyles) {
    element.style.minHeight = minHeight;
    element.style.height = height;
    element.style.flex = flex;
  }

  return {
    width: Math.ceil(Math.max(app.scrollWidth, app.getBoundingClientRect().width)),
    height: Math.ceil(contentBottom + paddingBottom),
  };
}

async function checkRcloneVersion(retries = 3, delayMs = 1000) {
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const rcloneVersion = await window.rcloneGui.getRcloneVersion();
      return rcloneVersion;
    } catch (error) {
      if (attempt === retries) {
        throw error;
      }
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }
}

async function syncMinimumWindowSize(forceSnap = false) {
  await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));

  const size = measureRequiredContentSize();
  if (!size || !window.rcloneGui?.fitWindowToContent) {
    return;
  }

  await window.rcloneGui.fitWindowToContent(
    { width: size.width },
    forceSnap,
  );
}



const UPDATE_STARTUP_DELAY_MS = 5000;
const UPDATE_RECHECK_MS = 24 * 60 * 60 * 1000;
let updateReleaseUrl = "";
let shownUpdateVersion = "";
let pendingUpdate = null;

let updateCapability = { canSelfUpdate: false };
let updatePhase = "available";
let updateProgress = null;
let updateErrorMessage = "";
let shownUpdate = null;

function formatUpdateBytes(size) {
  if (!Number.isFinite(size) || size < 0) {
    return "0 B";
  }
  if (size < 1024) {
    return `${Math.round(size)} B`;
  }
  const units = ["KB", "MB", "GB"];
  let value = size / 1024;
  let unitIndex = 0;
  while (value >= 1024 && unitIndex < units.length - 1) {
    value /= 1024;
    unitIndex += 1;
  }
  return `${value.toFixed(value >= 10 ? 0 : 1)} ${units[unitIndex]}`;
}

function cleanUpdateError(error, fallback) {
  return String(error?.message || "").replace(/^Error invoking remote method '[^']+': (?:Error: )?/, "") || fallback;
}

function hideUpdateDialog() {
  if (updatePhase === "installing") {
    return;
  }
  elements.updateDialog.classList.add("hidden");
  elements.updateDialog.setAttribute("aria-hidden", "true");
}

function setUpdateHint(text) {
  elements.updateHint.textContent = text;
  elements.updateHint.classList.toggle("hidden", !text);
}

function renderUpdateDialog() {
  const selfUpdate = updateCapability.canSelfUpdate;
  const phase = updatePhase;
  const busy = phase === "downloading" || phase === "installing";

  elements.updateTitle.textContent = phase === "downloaded" || phase === "installing" ? "Ready to update" : "Update available";

  const showProgress = phase === "downloading";
  elements.updateProgress.classList.toggle("hidden", !showProgress);
  if (showProgress) {
    const percent = Math.max(0, Math.min(100, Number(updateProgress?.percent) || 0));
    elements.updateProgressFill.style.width = `${percent}%`;
    elements.updateProgressBar.setAttribute("aria-valuenow", String(Math.round(percent)));
    elements.updateProgressText.textContent = updateProgress && updateProgress.total
      ? `${formatUpdateBytes(updateProgress.transferred)} of ${formatUpdateBytes(updateProgress.total)} · ${formatUpdateBytes(updateProgress.bytesPerSecond)}/s`
      : "Starting download…";
  }

  elements.updateError.textContent = updateErrorMessage;
  elements.updateError.classList.toggle("hidden", !updateErrorMessage);

  let hint = "";
  if (!selfUpdate) {
    hint = updateCapability.reason || "";
  } else if (phase === "downloaded" || phase === "installing") {
    if (updateCapability.kind === "deb") {
      hint = "Linux will ask for your password to install it.";
    } else if (updateCapability.kind === "portable") {
      hint = "Glasswing will close for a moment and start again.";
    }
  }
  setUpdateHint(hint);

  elements.updateNotes.classList.toggle("hidden", !selfUpdate || !updateReleaseUrl);

  elements.updateSkip.hidden = phase === "downloaded" || phase === "installing";
  elements.updateSkip.disabled = busy;
  elements.updateLater.disabled = phase === "installing";
  elements.updateLater.textContent = selfUpdate && (phase === "available" || phase === "downloading" || phase === "error") ? "Not now" : "Later";

  const primary = elements.updateOpen;
  primary.disabled = busy;
  if (!selfUpdate) {
    primary.textContent = "View release";
    primary.hidden = !updateReleaseUrl;
  } else {
    primary.hidden = false;
    primary.textContent = {
      available: "Download and install",
      downloading: "Downloading…",
      downloaded: "Restart to update",
      installing: "Restarting…",
      error: "Try again",
    }[phase];
  }
  elements.updateDialog.querySelector(".popup-card").setAttribute("aria-busy", String(busy));
}

function normalizeAppUpdateProgress(progress) {
  return {
    percent: Number(progress?.percent) || 0,
    transferred: Number(progress?.transferred) || 0,
    total: Number(progress?.total) || 0,
    bytesPerSecond: Number(progress?.bytesPerSecond) || 0,
  };
}

async function loadUpdateCapability() {
  try {
    const capability = await window.rcloneGui.getUpdateCapability?.();
    updateCapability = capability && typeof capability === "object" ? capability : { canSelfUpdate: false };
  } catch {
    updateCapability = { canSelfUpdate: false };
  }
}

async function syncDownloadedUpdate(version) {
  if (updatePhase === "downloading" || updatePhase === "installing") {
    return;
  }
  try {
    const downloaded = await window.rcloneGui.getDownloadedUpdate?.();
    if (downloaded?.version && downloaded.version === version) {
      updatePhase = "downloaded";
      updateErrorMessage = "";
    } else if (updatePhase === "downloaded") {
      updatePhase = "available";
    }
  } catch {
    return;
  }
}

async function startUpdateDownload() {
  if (updatePhase === "downloading" || updatePhase === "installing") {
    return;
  }
  const version = shownUpdateVersion;
  updatePhase = "downloading";
  updateProgress = null;
  updateErrorMessage = "";
  renderUpdateDialog();
  try {
    await window.rcloneGui.downloadUpdate();
    if (version !== shownUpdateVersion) {
      return;
    }
    updatePhase = "downloaded";
    const dialogOpen = !elements.updateDialog.classList.contains("hidden");
    renderUpdateDialog();
    if (!dialogOpen) {
      showSnackbar({
        title: "Update ready",
        message: "Click the refresh button next to the version to restart and finish updating.",
        type: "success",
      });
    }
  } catch (error) {
    if (version !== shownUpdateVersion) {
      return;
    }
    updatePhase = "error";
    updateErrorMessage = cleanUpdateError(error, "The update download failed.");
    renderUpdateDialog();
  }
}

async function startUpdateInstall() {
  if (updatePhase !== "downloaded") {
    return;
  }
  const version = shownUpdateVersion;
  updatePhase = "installing";
  updateErrorMessage = "";
  renderUpdateDialog();
  try {
    await window.rcloneGui.installUpdate();
  } catch (error) {
    if (version !== shownUpdateVersion) {
      return;
    }
    updatePhase = "downloaded";
    updateErrorMessage = cleanUpdateError(error, "Couldn't restart to update.");
    renderUpdateDialog();
  }
}

function setUpdateIndicator(update) {
  pendingUpdate = update;
  elements.updateDot?.classList.toggle("hidden", !update);
  elements.checkForUpdates.title = update ? `Update available: v${update.latestVersion}` : "Check for updates";
  elements.checkForUpdates.setAttribute("aria-label", elements.checkForUpdates.title);
}

async function showUpdateDialog(update) {
  const { currentVersion, latestVersion, publishedAt, releaseUrl } = update;
  if (shownUpdate?.latestVersion !== latestVersion) {
    updatePhase = "available";
    updateProgress = null;
    updateErrorMessage = "";
  }
  shownUpdate = update;
  shownUpdateVersion = latestVersion;
  updateReleaseUrl = releaseUrl || "";
  elements.updateCurrent.textContent = `v${currentVersion}`;
  elements.updateLatest.textContent = `v${latestVersion}`;

  const published = publishedAt ? new Date(publishedAt) : null;
  elements.updateDate.textContent = published && !Number.isNaN(published.getTime())
    ? `Released ${published.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" })}`
    : "";

  await loadUpdateCapability();
  if (updateCapability.canSelfUpdate) {
    await syncDownloadedUpdate(latestVersion);
  }
  renderUpdateDialog();
  elements.updateDialog.classList.remove("hidden");
  elements.updateDialog.setAttribute("aria-hidden", "false");
  (elements.updateOpen.hidden || elements.updateOpen.disabled ? elements.updateLater : elements.updateOpen).focus();
}

async function checkForUpdates({ automatic = false } = {}) {
  if (!automatic) {
    elements.checkForUpdates.classList.add("is-checking");
  }
  try {
    const result = await window.rcloneGui.checkForUpdates();

    if (result.hasUpdate) {
      setUpdateIndicator(result.skipped && automatic ? null : result);
      if (!automatic) {
        await showUpdateDialog(result);
      } else if (!result.skipped && shownUpdateVersion !== result.latestVersion) {
        await showUpdateDialog(result);
      }
    } else if (automatic) {
      setUpdateIndicator(null);
    } else {
      setUpdateIndicator(null);
      showSnackbar({
        title: "Up to date",
        message: `You're on the latest version (v${result.currentVersion}).`,
        type: "success",
      });
    }
  } catch (error) {
    if (automatic) {
      return;
    }
    showSnackbar({
      title: "Update check failed",
      message: error.message || "Could not check for updates",
      type: "error",
    });
  } finally {
    if (!automatic) {
      elements.checkForUpdates.classList.remove("is-checking");
    }
  }
}
const RCLONE_UPDATE_STARTUP_DELAY_MS = UPDATE_STARTUP_DELAY_MS + 4000;
const RCLONE_SKIP_KEY = "glasswing.skippedRcloneVersion";
let rcloneUpdate = null;
let rcloneUpdateBusy = false;
let rcloneUpdateChecking = false;

function readSkippedRcloneVersion() {
  try {
    return localStorage.getItem(RCLONE_SKIP_KEY) || "";
  } catch {
    return "";
  }
}

function writeSkippedRcloneVersion(version) {
  try {
    localStorage.setItem(RCLONE_SKIP_KEY, version);
  } catch {
    return;
  }
}

function setRcloneUpdateIndicator(update) {
  rcloneUpdate = update;
  elements.version.classList.toggle("has-update", Boolean(update));
  elements.version.title = update ? `rclone v${update.latest} available` : "Check for an rclone update";
}

function hideRcloneUpdateDialog() {
  if (rcloneUpdateBusy) {
    return;
  }
  elements.rcloneUpdateDialog.classList.add("hidden");
  elements.rcloneUpdateDialog.setAttribute("aria-hidden", "true");
}

function showRcloneUpdateDialog(update) {
  elements.rcloneUpdateCurrent.textContent = `v${update.current}`;
  elements.rcloneUpdateLatest.textContent = `v${update.latest}`;
  elements.rcloneUpdateError.textContent = "";
  elements.rcloneUpdateError.classList.add("hidden");
  elements.rcloneUpdateNote.hidden = false;
  elements.rcloneUpdateDialog.classList.remove("hidden");
  elements.rcloneUpdateDialog.setAttribute("aria-hidden", "false");
  elements.rcloneUpdateGo.focus();
}

function setRcloneUpdateBusy(busy) {
  rcloneUpdateBusy = busy;
  for (const button of [elements.rcloneUpdateSkip, elements.rcloneUpdateLater, elements.rcloneUpdateGo]) {
    button.disabled = busy;
  }
  elements.rcloneUpdateGo.textContent = busy ? "Updating…" : "Update rclone";
  elements.rcloneUpdateDialog.querySelector(".popup-card").setAttribute("aria-busy", String(busy));
}

async function checkRcloneUpdate({ automatic = false } = {}) {
  if (rcloneUpdateChecking || rcloneUpdateBusy) {
    return;
  }
  rcloneUpdateChecking = true;
  if (!automatic) {
    elements.version.classList.add("is-checking");
  }
  try {
    const result = await window.rcloneGui.checkRcloneUpdate();
    if (result.updateAvailable) {
      const skipped = readSkippedRcloneVersion() === result.latest;
      setRcloneUpdateIndicator(skipped && automatic ? null : result);
      if (!automatic) {
        showRcloneUpdateDialog(result);
      }
    } else {
      setRcloneUpdateIndicator(null);
      if (!automatic) {
        showSnackbar({
          title: "Up to date",
          message: `rclone is up to date (v${result.current}).`,
          type: "success",
        });
      }
    }
  } catch (error) {
    if (!automatic) {
      showSnackbar({
        title: "rclone update check failed",
        message: error.message || "Could not check for an rclone update",
        type: "error",
      });
    }
  } finally {
    rcloneUpdateChecking = false;
    elements.version.classList.remove("is-checking");
  }
}

async function runRcloneUpdate() {
  if (!rcloneUpdate || rcloneUpdateBusy) {
    return;
  }
  elements.rcloneUpdateError.classList.add("hidden");
  setRcloneUpdateBusy(true);
  try {
    const versionLine = await window.rcloneGui.updateRclone();
    const version = String(versionLine).replace(/^rclone\s+/, "");
    setRcloneUpdateBusy(false);
    setRcloneUpdateIndicator(null);
    elements.version.textContent = versionLine;
    hideRcloneUpdateDialog();
    showSnackbar({ title: "rclone updated", message: `rclone updated to ${version}`, type: "success" });
  } catch (error) {
    setRcloneUpdateBusy(false);
    elements.rcloneUpdateError.textContent = String(error?.message || "").replace(/^Error invoking remote method '[^']+': (?:Error: )?/, "") || "The rclone update failed.";
    elements.rcloneUpdateError.classList.remove("hidden");
    elements.rcloneUpdateGo.textContent = "Try again";
  }
}

const STORAGE_METER_INPUT_DELAY_MS = 600;
const pathMeters = window.StorageMeter
  ? {
      source: new window.StorageMeter(document.getElementById("source-storage")),
      destination: new window.StorageMeter(document.getElementById("destination-storage")),
    }
  : null;
let pathMeterTimer = null;

function updatePathMeters({ immediate = false } = {}) {
  if (!pathMeters) {
    return;
  }
  clearTimeout(pathMeterTimer);
  const apply = () => {
    pathMeters.source.setTarget(window.StorageUsage.targetForPath(elements.source.value, remotes));
    pathMeters.destination.setTarget(window.StorageUsage.targetForPath(elements.destination.value, remotes));
  };
  if (immediate) {
    apply();
  } else {
    pathMeterTimer = setTimeout(apply, STORAGE_METER_INPUT_DELAY_MS);
  }
}

function refreshPathMeters() {
  pathMeters?.source.refresh();
  pathMeters?.destination.refresh();
}

const modeIndicator = document.querySelector(".nav-indicator");

function positionModeIndicator() {
  const active = document.querySelector(".mode-switch-btn.is-active");
  if (!modeIndicator || !active) {
    return;
  }

  modeIndicator.style.setProperty("--indicator-x", `${active.offsetLeft}px`);
  modeIndicator.style.setProperty("--indicator-y", `${active.offsetTop}px`);
  modeIndicator.style.width = `${active.offsetWidth}px`;
  modeIndicator.style.height = `${active.offsetHeight}px`;

  if (!modeIndicator.classList.contains("is-ready")) {
    void modeIndicator.offsetWidth;
    modeIndicator.classList.add("is-ready");
  }
}

if (modeIndicator && window.ResizeObserver) {
  new ResizeObserver(() => positionModeIndicator()).observe(modeIndicator.parentElement);
}

function updateTitlebar(navButton) {
  const title = document.getElementById("titlebar-title");
  const icon = document.getElementById("titlebar-icon");
  if (!title || !icon) {
    return;
  }
  const label = navButton.querySelector(".nav-label")?.textContent || "";
  title.textContent = label;
  const glyph = navButton.querySelector(".nav-icon")?.cloneNode(true);
  icon.replaceChildren(...(glyph ? [glyph] : []));
}

function setAppMode(mode) {
  const nextMode = ["browse", "storage", "history"].includes(mode) ? mode : "jobs";
  const browsing = nextMode === "browse";

  elements.jobsView?.classList.toggle("hidden", nextMode !== "jobs");
  if (elements.jobsView) {
    elements.jobsView.hidden = nextMode !== "jobs";
  }

  for (const [button, buttonMode] of [
    [elements.modeJobs, "jobs"],
    [elements.modeBrowse, "browse"],
    [elements.modeStorage, "storage"],
    [elements.modeHistory, "history"],
  ]) {
    button?.classList.toggle("is-active", nextMode === buttonMode);
    button?.setAttribute("aria-selected", String(nextMode === buttonMode));
    if (nextMode === buttonMode && button) {
      updateTitlebar(button);
    }
  }
  positionModeIndicator();

  if (nextMode === "storage") {
    window.StorageView?.setRemotes(remotes);
    window.StorageView?.show();
  } else {
    window.StorageView?.hide();
  }

  if (nextMode === "history") {
    window.RunHistory?.show();
  } else {
    window.RunHistory?.hide();
  }

  if (browsing) {
    // Re-sync in case remotes loaded while Browse was hidden, or init raced.
    window.RemoteBrowser?.setRemotes(remotes);
    window.RemoteBrowser?.show();
  } else {
    window.RemoteBrowser?.hide();
  }

  void syncMinimumWindowSize(false);
}

function useBrowsePath({ path, target }) {
  if (!path) {
    return;
  }

  if (target === "destination") {
    elements.destination.value = path;
  } else {
    elements.source.value = path;
  }

  setAppMode("jobs");
  updateHistoryActions();
  updatePathMeters({ immediate: true });
  showSnackbar({
    title: target === "destination" ? "Destination set" : "Source set",
    message: path,
    type: "success",
  });
}

async function loadRemotes({ showFeedback = false } = {}) {
  if (!window.rcloneGui) {
    showSnackbar({
      title: "Reload failed",
      message: "App bridge unavailable.",
      type: "error",
    });
    return;
  }

  elements.refreshRemotes.disabled = true;

  try {
    remotes = await window.rcloneGui.listRemotes();
    fillRemotePicker();
    updatePathMeters({ immediate: true });
    window.RemoteBrowser?.setRemotes(remotes);
    window.StorageView?.setRemotes(remotes);

    const countLabel = `${remotes.length} remote${remotes.length === 1 ? "" : "s"}`;

    if (showFeedback) {
      showSnackbar({
        title: "Remotes reloaded",
        message: `Successfully loaded ${countLabel}.`,
        type: "success",
      });
    }
  } catch (error) {
    showSnackbar({
      title: "Reload failed",
      message: error.message || "Could not list remotes.",
      type: "error",
    });
  } finally {
    elements.refreshRemotes.disabled = false;
  }
}



async function init() {
  try {
    if (!window.rcloneGui) {
      elements.version.textContent = "App bridge unavailable";
      setStatus("Restart the app to reload the interface.", "error");
      elements.runJob.disabled = true;
      return;
    }

    // Show the window immediately — never block the first paint on rclone I/O.
    await window.rcloneGui.showMainWindow();

    let rcloneVersion = "";
    elements.version.textContent = "Checking rclone…";
    window.rcloneGui.getAppVersion().then((version) => {
      elements.appVersion.textContent = `v${version}`;
    });
    const historyLoad = refreshJobHistory().catch(() => {});
    const remotesLoad = window.rcloneGui.listRemotes().then(
      (names) => ({ names }),
      (error) => ({ error }),
    );
    try {
      rcloneVersion = await checkRcloneVersion();
      elements.version.textContent = `${rcloneVersion} · loading remotes…`;
    } catch (error) {
      const notFound = error?.code === "ENOENT" || /ENOENT/.test(String(error?.message));
      elements.version.textContent = notFound ? "rclone not found on PATH" : "rclone failed to start";
      setStatus(
        notFound
          ? "Install rclone and ensure it is available on PATH."
          : `rclone was found but didn't run: ${String(error?.message || error).replace(/^Error invoking remote method '[^']+': (Error: )?/, "")}`,
        "error",
      );
      elements.runJob.disabled = true;
      return;
    }

    const [remotesResult] = await Promise.all([remotesLoad, historyLoad]);
    attachToRunningJob(await window.rcloneGui.getActiveJob().catch(() => null));
    if (remotesResult.error) {
      await loadRemotes({ showFeedback: false });
    } else {
      remotes = remotesResult.names;
      fillRemotePicker();
      updatePathMeters({ immediate: true });
    }
    window.RemoteBrowser?.setRemotes(remotes);
    window.StorageView?.setRemotes(remotes);
    elements.version.textContent = rcloneVersion;
    elements.operation.dispatchEvent(new Event("change"));
  } finally {
    if (window.rcloneGui) {
      await syncMinimumWindowSize(true);
      await window.rcloneGui.showMainWindow();
    }
  }
}



elements.operation.addEventListener("change", () => {

  const operation = elements.operation.value;

  elements.operationHint.textContent = operationHints[operation];

  elements.deleteExcluded.disabled = operation !== "sync" || activeJobId !== null;

  elements.resyncOption.classList.toggle("hidden", operation !== "bisync");

  if (operation !== "bisync") {
    elements.resync.checked = false;
  }

});

const operationSegment = document.getElementById("operation-segment");
const operationChoices = [...operationSegment.querySelectorAll("[data-operation-choice]")];

function syncOperationSegment() {
  const index = Math.max(
    0,
    operationChoices.findIndex((choice) => choice.dataset.operationChoice === elements.operation.value),
  );
  operationSegment.style.setProperty("--segment-index", String(index));
  operationChoices.forEach((choice, choiceIndex) => {
    choice.setAttribute("aria-checked", String(choiceIndex === index));
    choice.tabIndex = choiceIndex === index ? 0 : -1;
  });
}

function chooseOperation(value) {
  if (elements.operation.disabled || elements.operation.value === value) {
    return;
  }
  elements.operation.value = value;
  elements.operation.dispatchEvent(new Event("change"));
}

operationChoices.forEach((choice, choiceIndex) => {
  choice.addEventListener("click", () => chooseOperation(choice.dataset.operationChoice));
  choice.addEventListener("keydown", (event) => {
    const step = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[event.key];
    if (!step) {
      return;
    }
    event.preventDefault();
    const next = operationChoices[(choiceIndex + step + operationChoices.length) % operationChoices.length];
    chooseOperation(next.dataset.operationChoice);
    if (!elements.operation.disabled) {
      next.focus();
    }
  });
});

elements.operation.addEventListener("change", syncOperationSegment);
syncOperationSegment();

document.getElementById("swap-paths").addEventListener("click", () => {
  if (elements.source.disabled || elements.destination.disabled) {
    return;
  }
  [elements.source.value, elements.destination.value] = [elements.destination.value, elements.source.value];
  for (const input of [elements.source, elements.destination]) {
    input.dispatchEvent(new Event("change"));
  }
});



document.querySelectorAll("[data-target]").forEach((button) => {

  button.addEventListener("click", async () => {

    const targetId = button.getAttribute("data-target");

    const folder = await window.rcloneGui.pickFolder();

    if (folder) {

      document.getElementById(targetId).value = folder;

      updatePathMeters({ immediate: true });

    }

  });

});



document.getElementById("insert-remote-source").addEventListener("click", () => {

  const remote = elements.remotePicker.value;

  if (!remote) {

    setStatus("Pick a remote first.", "error");

    return;

  }



  elements.source.value = formatRemotePath(remote, elements.remotePath.value);
  updatePathMeters({ immediate: true });

});



document.getElementById("insert-remote-dest").addEventListener("click", () => {

  const remote = elements.remotePicker.value;

  if (!remote) {

    setStatus("Pick a remote first.", "error");

    return;

  }



  elements.destination.value = formatRemotePath(remote, elements.remotePath.value);
  updatePathMeters({ immediate: true });

});



elements.refreshRemotes.addEventListener("click", () => loadRemotes({ showFeedback: true }));

elements.modeJobs?.addEventListener("click", () => setAppMode("jobs"));
elements.modeBrowse?.addEventListener("click", () => setAppMode("browse"));
elements.modeStorage?.addEventListener("click", () => setAppMode("storage"));
elements.modeHistory?.addEventListener("click", () => setAppMode("history"));
updateTitlebar(document.querySelector(".mode-switch-btn.is-active") || elements.modeJobs);

window.StorageView?.setOptions({
  notify: showSnackbar,
  onBrowse: (name) => {
    setAppMode("browse");
    window.RemoteBrowser?.browseRemote(name);
  },
});

window.MigrationWizard?.init({ onNotify: showSnackbar });

window.RemoteBrowser?.init({
  onUsePath: useBrowsePath,
  onNotify: showSnackbar,
});

elements.manageRemotes?.addEventListener("click", () => {
  window.RemoteManager?.open({
    onChanged: async (names) => {
      remotes = names;
      fillRemotePicker();
      updatePathMeters({ immediate: true });
      window.RemoteBrowser?.setRemotes(remotes);
      window.StorageView?.setRemotes(remotes);
    },
    onBrowse: (name) => {
      setAppMode("browse");
      window.RemoteBrowser?.browseRemote(name);
    },
  });
});
elements.popupClose.addEventListener("click", hidePopup);
elements.updateLater.addEventListener("click", hideUpdateDialog);
elements.updateSkip?.addEventListener("click", async () => {
  const version = shownUpdateVersion;
  hideUpdateDialog();
  if (pendingUpdate?.latestVersion === version) {
    setUpdateIndicator(null);
  }
  try {
    await window.rcloneGui.skipUpdateVersion(version);
    showSnackbar({
      title: "Version skipped",
      message: `You won't be reminded about v${version}. The refresh button next to the version still checks.`,
      type: "success",
    });
  } catch (error) {
    showSnackbar({ title: "Couldn't skip that version", message: error.message || "", type: "error" });
  }
});
elements.version.addEventListener("click", () => {
  if (rcloneUpdate) {
    showRcloneUpdateDialog(rcloneUpdate);
  } else if (window.rcloneGui) {
    void checkRcloneUpdate();
  }
});
elements.rcloneUpdateLater.addEventListener("click", hideRcloneUpdateDialog);
elements.rcloneUpdateGo.addEventListener("click", () => void runRcloneUpdate());
elements.rcloneUpdateSkip.addEventListener("click", () => {
  const version = rcloneUpdate?.latest;
  hideRcloneUpdateDialog();
  if (!version) {
    return;
  }
  writeSkippedRcloneVersion(version);
  setRcloneUpdateIndicator(null);
  showSnackbar({
    title: "Version skipped",
    message: `You won't be reminded about rclone v${version}. Click the rclone version to check again.`,
    type: "success",
  });
});
elements.rcloneUpdateDialog.querySelector("[data-rclone-update-close]").addEventListener("click", hideRcloneUpdateDialog);
elements.updateDialog.querySelector("[data-update-close]").addEventListener("click", hideUpdateDialog);
elements.updateOpen.addEventListener("click", () => {
  if (!updateCapability.canSelfUpdate) {
    if (updateReleaseUrl) {
      void window.rcloneGui.openReleasePage();
    }
    hideUpdateDialog();
  } else if (updatePhase === "downloaded") {
    void startUpdateInstall();
  } else {
    void startUpdateDownload();
  }
});
elements.updateNotes.addEventListener("click", () => {
  if (updateReleaseUrl) {
    void window.rcloneGui.openReleasePage();
  }
});
window.rcloneGui?.onAppUpdateProgress?.((progress) => {
  if (updatePhase !== "downloading") {
    return;
  }
  updateProgress = normalizeAppUpdateProgress(progress);
  renderUpdateDialog();
});
elements.popupRoot.querySelector("[data-popup-close]").addEventListener("click", hidePopup);

elements.jobHistoryPicker.addEventListener("change", updateHistoryActions);

for (const input of [elements.source, elements.destination]) {
  input.addEventListener("input", () => updatePathMeters());
  input.addEventListener("change", () => updatePathMeters({ immediate: true }));
}

for (const input of [
  elements.operation,
  elements.source,
  elements.destination,
  elements.dryRun,
  elements.deleteExcluded,
  elements.extraArgs,
]) {
  input.addEventListener("input", updateHistoryActions);
  input.addEventListener("change", updateHistoryActions);
}

elements.loadJob.addEventListener("click", () => {
  const entry = getSelectedHistoryEntry();
  if (!entry) {
    return;
  }

  applyJobToForm(entry, { fromSavedJob: true });
  elements.jobHistoryCollapsible.open = false;
  showSnackbar({
    title: "Job loaded",
    message: `"${entry.name}" has been loaded.`,
    type: "success",
  });
});

elements.updateJob.addEventListener("click", async () => {
  const entry = getSelectedHistoryEntry();
  if (!entry) {
    return;
  }

  const job = getCurrentJobConfig();
  if (!job.source || !job.destination) {
    setStatus("Source and destination are required.", "error");
    return;
  }

  try {
    jobHistory = await window.rcloneGui.updateJob(entry.id, job);
    fillJobHistoryPicker(entry.id);
    showSnackbar({
      title: "Job updated",
      message: `"${entry.name}" now matches the current form.`,
      type: "success",
    });
  } catch (error) {
    setStatus(error.message, "error");
  }
});

elements.saveJob.addEventListener("click", showSaveJobDialog);
elements.saveJobConfirm.addEventListener("click", () => {
  void confirmSaveJob();
});
elements.saveJobCancel.addEventListener("click", hideSaveJobDialog);
elements.saveJobDialog.querySelector("[data-save-dialog-close]").addEventListener("click", hideSaveJobDialog);

elements.saveJobName.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    event.preventDefault();
    void confirmSaveJob();
  }
});

elements.scheduleJob.addEventListener("click", () => {
  const entry = getSelectedHistoryEntry();
  if (!entry) {
    return;
  }

  void window.JobSchedule.open(entry, {
    onSaved: (saved, jobs) => {
      jobHistory = jobs;
      fillJobHistoryPicker(entry.id);
      showSnackbar({
        title: saved?.schedule?.enabled ? "Job scheduled" : "Schedule turned off",
        message: saved?.schedule?.enabled
          ? [{ strong: entry.name }, ` runs next ${window.JobSchedule.formatNextRun(saved.schedule.nextRunAt)}.`]
          : [{ strong: entry.name }, " only runs when you start it."],
        type: "success",
      });
    },
  });
});

elements.deleteJob.addEventListener("click", async () => {
  const entry = getSelectedHistoryEntry();
  if (!entry) {
    return;
  }

  try {
    jobHistory = await window.rcloneGui.deleteJob(entry.id);
    fillJobHistoryPicker();
    setStatus("Saved job removed.", "success", {
      hideAfter: 4000,
      ensureVisible: true,
    });
  } catch (error) {
    setStatus(error.message, "error");
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    if (!elements.saveJobDialog.classList.contains("hidden")) {
      hideSaveJobDialog();
      return;
    }

    if (!elements.rcloneUpdateDialog.classList.contains("hidden")) {
      hideRcloneUpdateDialog();
      return;
    }

    if (!elements.updateDialog.classList.contains("hidden")) {
      hideUpdateDialog();
      return;
    }

    if (!elements.popupRoot.classList.contains("hidden")) {
      hidePopup();
    }
  }
});

elements.runJob.addEventListener("click", () => {
  void startJobFromForm();
});



elements.stopJob.addEventListener("click", async () => {
  showSnackbar({
    title: "Stopping job",
    message: "Waiting for rclone to finish…",
    type: "running",
  });
  await window.rcloneGui.stopJob();
});

elements.checkForUpdates.addEventListener("click", () => {
  if (pendingUpdate && (updatePhase === "downloading" || updatePhase === "downloaded")) {
    void showUpdateDialog(pendingUpdate);
    return;
  }
  void checkForUpdates();
});

const explorerMenu = {
  toggle: document.getElementById("explorer-menu-toggle"),
  divider: document.getElementById("explorer-menu-divider"),
  offer: document.getElementById("explorer-offer-dialog"),
  offerYes: document.getElementById("explorer-offer-yes"),
  offerNo: document.getElementById("explorer-offer-no"),
};

function receiveExplorerUploads(paths) {
  if (!paths?.length) {
    return;
  }
  setAppMode("browse");
  window.RemoteBrowser?.queueUpload(paths);
}

function renderExplorerMenu(state) {
  const supported = Boolean(state?.supported);
  explorerMenu.toggle?.classList.toggle("hidden", !supported);
  explorerMenu.divider?.classList.toggle("hidden", !supported);
  explorerMenu.toggle?.setAttribute("aria-checked", String(Boolean(state?.enabled)));
}

function hideExplorerOffer() {
  explorerMenu.offer?.classList.add("hidden");
  explorerMenu.offer?.setAttribute("aria-hidden", "true");
}

async function setExplorerMenu(enabled) {
  try {
    renderExplorerMenu(await window.rcloneGui.setExplorerMenu(enabled));
    showSnackbar(enabled
      ? { title: "Added to Explorer", message: "Right-click files or folders and pick Upload with Glasswing. On Windows 11 it's under Show more options.", type: "success" }
      : { title: "Removed from Explorer", message: "Upload with Glasswing is gone from the right-click menu.", type: "success" });
  } catch (error) {
    showSnackbar({ title: "Couldn't change the Explorer menu", message: String(error.message || "").replace(/^Error invoking remote method '[^']+': (?:Error: )?/, ""), type: "error" });
  }
}

async function initExplorerMenu() {
  if (!window.rcloneGui?.getExplorerMenu) {
    return;
  }
  window.rcloneGui.onExplorerUpload?.(receiveExplorerUploads);
  receiveExplorerUploads(await window.rcloneGui.takeExplorerUploads().catch(() => []));
  const state = await window.rcloneGui.getExplorerMenu().catch(() => null);
  renderExplorerMenu(state);
  if (state?.offer && explorerMenu.offer) {
    setTimeout(() => {
      explorerMenu.offer.classList.remove("hidden");
      explorerMenu.offer.setAttribute("aria-hidden", "false");
      explorerMenu.offerYes.focus();
    }, 1500);
  }
}

explorerMenu.toggle?.addEventListener("click", () => {
  void setExplorerMenu(explorerMenu.toggle.getAttribute("aria-checked") !== "true");
});
explorerMenu.offerYes?.addEventListener("click", () => {
  hideExplorerOffer();
  void setExplorerMenu(true);
});
for (const dismiss of [explorerMenu.offerNo, explorerMenu.offer?.querySelector("[data-explorer-offer-close]")]) {
  dismiss?.addEventListener("click", () => {
    hideExplorerOffer();
    void window.rcloneGui.dismissExplorerMenuOffer();
  });
}
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && explorerMenu.offer && !explorerMenu.offer.classList.contains("hidden")) {
    event.stopPropagation();
    hideExplorerOffer();
    void window.rcloneGui.dismissExplorerMenuOffer();
  }
}, true);
void initExplorerMenu();
setTimeout(() => {
  void checkForUpdates({ automatic: true });
  setInterval(() => void checkForUpdates({ automatic: true }), UPDATE_RECHECK_MS);
}, UPDATE_STARTUP_DELAY_MS);
setTimeout(() => {
  void checkRcloneUpdate({ automatic: true });
}, RCLONE_UPDATE_STARTUP_DELAY_MS);



function attachToRunningJob(job) {
  if (!job || activeJobId !== null) {
    return;
  }

  activeJobId = job.id;
  setRunning(true);
  outputPanel.startJob({
    operation: job.operation,
    source: job.source,
    destination: job.destination,
  });

  if (job.scheduled) {
    showSnackbar({
      title: "Scheduled job running",
      message: [{ strong: job.scheduled.name }, " started on schedule."],
      type: "running",
    });
  }
}

window.RunHistory?.setOptions({
  canLoad: () => !jobRunning,
  onLoad: (run) => {
    setAppMode("jobs");
    applyJobToForm(run, { fromSavedJob: true });
    if (jobHistory.some((entry) => entry.id === run.jobId)) {
      fillJobHistoryPicker(run.jobId);
    }
    updateHistoryActions();
    showSnackbar({
      title: "Job loaded",
      message: `Loaded the settings from ${escapeHtml(run.name ? `"${run.name}"` : "that run")}.`,
      type: "success",
    });
  },
});

window.rcloneGui.onJobStarted((job) => {
  if (!job.scheduled) {
    return;
  }

  attachToRunningJob(job);
  void refreshJobHistory(elements.jobHistoryPicker.value);
});

window.rcloneGui.onSchedulesChanged(() => {
  void refreshJobHistory(elements.jobHistoryPicker.value);
});

window.rcloneGui.onJobOutput(({ id, text }) => {

  if (id !== activeJobId) {

    return;

  }



  outputPanel.appendOutput(text);

});



window.rcloneGui.onMountsChanged?.(({ event }) => {
  if (!event) {
    return;
  }

  if (event.type === "mounted") {
    showSnackbar({
      title: "Drive mounted",
      message: [{ strong: event.remote }, ` is now available as ${event.mountPoint}`],
      type: "success",
    });
  } else if (event.unexpected) {
    showPopup({
      title: `${event.mountPoint} was unmounted`,
      message: `The mount for "${event.remote}" stopped unexpectedly. ${event.message}`,
      type: "error",
      autoClose: false,
    });
  } else if (event.type === "unmounted") {
    showSnackbar({
      title: "Drive unmounted",
      message: [`${event.mountPoint} (`, { strong: event.remote }, ") is no longer mounted"],
      type: "success",
    });
  }
});

window.rcloneGui.onServesChanged?.(({ event }) => {
  if (!event) {
    return;
  }

  if (event.type === "started") {
    showSnackbar({
      title: `${event.label} serve started`,
      message: [{ strong: event.remote }, ` is being shared at ${event.url}`],
      type: "success",
    });
  } else if (event.unexpected) {
    showPopup({
      title: `${event.label} serve stopped`,
      message: `The serve for "${event.remote}" on port ${event.port} stopped unexpectedly. ${event.message}`,
      type: "error",
      autoClose: false,
    });
  } else {
    showSnackbar({
      title: `${event.label} serve stopped`,
      message: [{ strong: event.remote }, ` is no longer shared on port ${event.port}`],
      type: "success",
    });
  }
});

window.rcloneGui.onJobFinished(({ id, success, message, cancelled, needsResync }) => {

  if (id !== activeJobId) {

    return;

  }



  outputPanel.flush();

  activeJobId = null;

  setRunning(false);

  outputPanel.finishJob({ success, message, cancelled });
  refreshPathMeters();

  if (needsResync && elements.operation.value === "bisync") {
    elements.resync.checked = true;
  } else if (success) {
    elements.resync.checked = false;
  }

  if (cancelled) {
    showSnackbar({
      title: "Job cancelled",
      message: message || "The job was stopped.",
      type: "running",
    });
  } else if (success) {
    showSnackbar({
      title: "Job completed",
      message: message || "The job finished successfully.",
      type: "success",
    });
  } else {
    showSnackbar({
      title: "Job failed",
      message: message || "The job ended with errors.",
      type: "error",
    });
  }

  void refreshJobHistory(elements.jobHistoryPicker.value);
});



void init();


