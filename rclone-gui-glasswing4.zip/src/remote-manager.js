const POPULAR_PROVIDERS = [
  "drive",
  "dropbox",
  "onedrive",
  "s3",
  "b2",
  "local",
  "sftp",
  "webdav",
  "box",
  "mega",
  "pcloud",
  "ftp",
  "crypt",
];

const remoteManager = {
  dialog: document.getElementById("remote-manager-dialog"),
  configPath: document.getElementById("remote-manager-config-path"),
  list: document.getElementById("remote-list"),
  listEmpty: document.getElementById("remote-list-empty"),
  panelEmpty: document.getElementById("remote-panel-empty"),
  panelDetail: document.getElementById("remote-panel-detail"),
  panelAdd: document.getElementById("remote-panel-add"),
  panelVault: document.getElementById("remote-panel-vault"),
  vaultBtn: document.getElementById("remote-vault-btn"),
  detailName: document.getElementById("remote-detail-name"),
  detailType: document.getElementById("remote-detail-type"),
  detailConfig: document.getElementById("remote-detail-config"),
  createName: document.getElementById("remote-create-name"),
  providerSearch: document.getElementById("remote-provider-search"),
  providerSelect: document.getElementById("remote-provider-select"),
  providerDescription: document.getElementById("remote-provider-description"),
  providerForm: document.getElementById("remote-provider-form"),
  showAdvanced: document.getElementById("remote-show-advanced"),
  createError: document.getElementById("remote-create-error"),
  authorizeBtn: document.getElementById("remote-authorize-btn"),
  addBtn: document.getElementById("remote-add-btn"),
  refreshBtn: document.getElementById("remote-refresh-btn"),
  reconnectBtn: document.getElementById("remote-reconnect-btn"),
  deleteBtn: document.getElementById("remote-delete-btn"),
  createCancelBtn: document.getElementById("remote-create-cancel"),
  createSubmitBtn: document.getElementById("remote-create-submit"),
  openWizardBtn: document.getElementById("remote-open-wizard-btn"),
  closeBtn: document.getElementById("remote-manager-close"),
  mountSection: document.getElementById("remote-mount"),
  mountStatus: document.getElementById("remote-mount-status"),
  mountForm: document.getElementById("remote-mount-form"),
  mountLetter: document.getElementById("remote-mount-letter"),
  mountLetterField: document.getElementById("remote-mount-letter").closest(".field"),
  mountFolderField: document.getElementById("remote-mount-folder-field"),
  mountFolder: document.getElementById("remote-mount-folder"),
  mountFolderPick: document.getElementById("remote-mount-folder-pick"),
  mountTitleText: document.getElementById("remote-mount-title-text"),
  mountCache: document.getElementById("remote-mount-cache"),
  mountReadOnly: document.getElementById("remote-mount-readonly"),
  mountBtn: document.getElementById("remote-mount-btn"),
  mountActive: document.getElementById("remote-mount-active"),
  mountOpenBtn: document.getElementById("remote-mount-open"),
  unmountBtn: document.getElementById("remote-unmount-btn"),
  mountHint: document.getElementById("remote-mount-hint"),
  mountAlert: document.getElementById("remote-mount-alert"),
  mountAlertText: document.getElementById("remote-mount-alert-text"),
  mountReconnectBtn: document.getElementById("remote-mount-reconnect"),
  detailAvatar: document.getElementById("remote-detail-avatar"),
};

let remoteEntries = [];
let providers = [];
let selectedRemoteName = null;
let onRemotesChanged = null;
let onBrowseRemote = null;
let busy = false;
let mountStatus = null;
let mountError = "";
let mountPending = "";
let mountFailure = null;
let mountChecking = false;
const mountFolders = new Map();

function isLinuxMount() {
  return mountStatus?.platform === "linux" || mountStatus?.platform === "darwin";
}

function isMacMount() {
  return mountStatus?.platform === "darwin";
}

function mountBlocked() {
  if (isLinuxMount()) {
    return !mountStatus.fuse?.available;
  }
  return !(mountStatus?.freeDriveLetters || []).length;
}

function shortMountPoint(mountPoint) {
  return `…/${mountPoint.split("/").pop()}`;
}

function defaultMountFolder(name) {
  return `${mountStatus.mountRoot}/${name.replaceAll("/", "_")}`;
}

function setBusy(nextBusy) {
  busy = nextBusy;
  const controls = [
    remoteManager.addBtn,
    remoteManager.refreshBtn,
    remoteManager.vaultBtn,
    remoteManager.reconnectBtn,
    remoteManager.deleteBtn,
    remoteManager.createCancelBtn,
    remoteManager.createSubmitBtn,
    remoteManager.authorizeBtn,
    remoteManager.openWizardBtn,
    remoteManager.mountBtn,
    remoteManager.mountOpenBtn,
    remoteManager.unmountBtn,
  ];

  for (const control of controls) {
    if (control) {
      control.disabled = nextBusy;
    }
  }

  if (!nextBusy && mountBlocked()) {
    remoteManager.mountBtn.disabled = true;
  }
}

function showCreateError(message = "") {
  if (!message) {
    remoteManager.createError.textContent = "";
    remoteManager.createError.classList.add("hidden");
    return;
  }

  remoteManager.createError.textContent = message;
  remoteManager.createError.classList.remove("hidden");
}

function showPanel(mode) {
  remoteManager.panelEmpty.classList.toggle("hidden", mode !== "empty");
  remoteManager.panelDetail.classList.toggle("hidden", mode !== "detail");
  remoteManager.panelAdd.classList.toggle("hidden", mode !== "add");
  remoteManager.panelVault.classList.toggle("hidden", mode !== "vault");
  if (mode !== "detail") {
    window.RemoteServe?.hide();
  }
  if (mode !== "vault") {
    window.VaultWizard?.reset();
  }
}

function paintAvatar(node, name) {
  if (!node) {
    return;
  }
  let hue = 0;
  for (const char of name) {
    hue = (hue * 31 + char.charCodeAt(0)) % 360;
  }
  node.textContent = (/[a-z0-9]/i.exec(name)?.[0] || "?").toUpperCase();
  node.style.setProperty("--avatar-hue", String(hue));
}

function replayAnimation(node, className) {
  node.classList.remove(className);
  void node.offsetWidth;
  node.classList.add(className);
}

function renderRemoteList() {
  remoteManager.list.innerHTML = "";
  remoteManager.listEmpty.classList.toggle("hidden", remoteEntries.length > 0);

  remoteEntries.forEach((entry, index) => {
    const item = document.createElement("li");
    item.style.setProperty("--i", String(index));
    const button = document.createElement("button");
    button.type = "button";
    button.className = `remote-list-item${entry.name === selectedRemoteName ? " is-selected" : ""}`;
    button.dataset.remoteName = entry.name;

    const avatar = document.createElement("span");
    avatar.className = "remote-avatar";
    avatar.setAttribute("aria-hidden", "true");
    paintAvatar(avatar, entry.name);

    const name = document.createElement("span");
    name.className = "remote-list-item-name";
    name.textContent = entry.name;

    const type = document.createElement("span");
    type.className = "remote-type-badge";
    type.textContent = entry.type;

    const mount = getMount(entry.name);
    if (mount) {
      const drive = document.createElement("span");
      drive.className = "remote-mount-badge";
      drive.textContent = isLinuxMount() ? shortMountPoint(mount.mountPoint) : mount.mountPoint;
      drive.title = `Mounted at ${mount.mountPoint}`;
      const badges = document.createElement("span");
      badges.className = "remote-list-item-badges";
      badges.append(drive, type);
      button.append(avatar, name, badges);
    } else {
      button.append(avatar, name, type);
    }
    button.addEventListener("click", () => {
      void selectRemote(entry.name);
    });

    item.appendChild(button);
    remoteManager.list.appendChild(item);
  });
}

function getMount(name) {
  return mountStatus?.mounts?.find((mount) => mount.remote === name) || null;
}

function renderMountLetters() {
  const select = remoteManager.mountLetter;
  const previous = select.value;
  const letters = mountStatus?.freeDriveLetters || [];
  select.innerHTML = "";

  for (const letter of letters) {
    const option = document.createElement("option");
    option.value = letter;
    option.textContent = `${letter}:`;
    select.appendChild(option);
  }

  if (letters.length === 0) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "No free letters";
    select.appendChild(option);
  } else if (letters.includes(previous)) {
    select.value = previous;
  }
}

function renderLinuxMountFields(name) {
  if (!remoteManager.mountFolder.matches(":focus") && !mountPending) {
    remoteManager.mountFolder.value = mountFolders.get(name) || defaultMountFolder(name);
  }
}

function renderMountPanel() {
  const section = remoteManager.mountSection;
  if (!selectedRemoteName || !mountStatus?.supported) {
    section.classList.add("hidden");
    return;
  }

  section.classList.remove("hidden");
  const mount = getMount(selectedRemoteName);
  const linuxMode = isLinuxMount();
  remoteManager.mountLetterField.classList.toggle("hidden", linuxMode);
  remoteManager.mountFolderField.classList.toggle("hidden", !linuxMode);
  if (linuxMode) {
    remoteManager.mountTitleText.textContent = "Mount as folder";
    remoteManager.mountOpenBtn.textContent = isMacMount() ? "Show in Finder" : "Open folder";
  }

  remoteManager.mountForm.classList.toggle("hidden", Boolean(mount));
  remoteManager.mountActive.classList.toggle("hidden", !mount);
  remoteManager.mountStatus.textContent = mount ? `Mounted at ${mount.mountPoint}` : mountChecking ? "Checking sign-in…" : mountPending;
  remoteManager.mountStatus.classList.toggle("is-mounted", Boolean(mount));

  let hint;
  if (mount) {
    const details = [mount.readOnly ? "read-only" : "", `${mount.cacheMode} cache`].filter(Boolean).join(", ");
    hint = `Mounted with ${details}. The ${isLinuxMount() ? "folder" : "drive"} stays available while Glasswing is open.`;
  } else {
    if (linuxMode) {
      renderLinuxMountFields(selectedRemoteName);
    } else if (!mountPending) {
      renderMountLetters();
    }
    hint = linuxMode
      ? `Show this remote as a folder in ${isMacMount() ? "Finder" : "your file manager"}. It stays mounted while Glasswing is open.`
      : "Show this remote as a drive in File Explorer. It stays mounted while Glasswing is open.";
    if (linuxMode && !mountStatus.fuse?.available) {
      hint = mountStatus.fuse?.message || "Mounting needs FUSE. Install fuse3 (e.g. `sudo apt install fuse3`) and try again.";
    }
  }

  remoteManager.mountHint.textContent = mountError || hint;
  remoteManager.mountHint.classList.toggle("is-error", Boolean(mountError));
  renderMountAlert();
  remoteManager.mountBtn.textContent = mountChecking ? "Checking sign-in…" : mountPending ? "Mounting…" : "Mount";
  if (!busy) {
    remoteManager.mountBtn.disabled = mountBlocked();
  }
}

function selectedRemoteUsesOAuth() {
  const entry = remoteEntries.find((item) => item.name === selectedRemoteName);
  return optionNeedsAuthorize(providers.find((item) => item.Name === entry?.type));
}

function mountFailureText(failure, name) {
  if (failure.code === "auth") {
    if (remoteEntries.find((item) => item.name === name)?.type === "crypt") {
      return `The sign-in or credentials for the storage behind ${name} were rejected. Reconnect the remote it uses and try again.`;
    }
    return selectedRemoteUsesOAuth()
      ? `Your sign-in for ${name} has expired. Reconnect and try again.`
      : `The credentials for ${name} were rejected. Check them in the remote's config and try again.`;
  }
  if (failure.code === "unreachable") {
    return `Couldn't reach ${name}. Check your connection and try again.`;
  }
  return failure.message || `Couldn't check ${name} before mounting.`;
}

function renderMountAlert() {
  const failure = mountFailure?.name === selectedRemoteName ? mountFailure : null;
  remoteManager.mountAlert.classList.toggle("hidden", !failure);
  if (!failure) {
    return;
  }
  remoteManager.mountAlertText.textContent = mountFailureText(failure, failure.name);
  const canReconnect = failure.code === "auth" && selectedRemoteUsesOAuth();
  remoteManager.mountReconnectBtn.classList.toggle("hidden", !canReconnect);
}

async function reconnectFromMountAlert() {
  const name = selectedRemoteName;
  if (!name) {
    return;
  }
  mountFailure = null;
  await reconnectSelectedRemote();
  renderMountPanel();
}

async function refreshMountStatus() {
  if (!window.rcloneGui?.getMountStatus) {
    return;
  }

  try {
    mountStatus = await window.rcloneGui.getMountStatus();
  } catch {
    mountStatus = null;
  }
  renderRemoteList();
  renderMountPanel();
}

function cleanIpcError(error, fallback) {
  const message = String(error?.message || "").replace(/^Error invoking remote method '[^']+': (?:Error: )?/, "");
  return message || fallback;
}

async function mountSelectedRemote() {
  const name = selectedRemoteName;
  const linuxMode = isLinuxMount();
  const driveLetter = remoteManager.mountLetter.value;
  const mountPoint = remoteManager.mountFolder.value.trim();
  if (!name || (linuxMode ? !mountPoint : !driveLetter)) {
    return;
  }

  mountError = "";
  mountFailure = null;
  if (linuxMode) {
    mountFolders.set(name, mountPoint);
  }
  mountPending = linuxMode ? `Mounting at ${mountPoint}…` : `Mounting at ${driveLetter}:…`;
  mountChecking = true;
  setBusy(true);
  renderMountPanel();
  try {
    const result = await window.rcloneGui.mountRemote({
      remote: name,
      driveLetter,
      mountPoint,
      cacheMode: remoteManager.mountCache.value,
      readOnly: remoteManager.mountReadOnly.checked,
    });
    if (result?.failure) {
      mountFailure = { ...result.failure, name };
      mountPending = "";
    } else {
      mountStatus = result;
    }
  } catch (error) {
    mountError = cleanIpcError(error, "Could not mount the remote.");
    mountPending = "";
    await refreshMountStatus();
  } finally {
    mountPending = "";
    mountChecking = false;
    setBusy(false);
    renderRemoteList();
    renderMountPanel();
  }
}

async function unmountSelectedRemote() {
  const name = selectedRemoteName;
  if (!name) {
    return;
  }

  mountError = "";
  setBusy(true);
  try {
    let result = await window.rcloneGui.unmountRemote(name);
    if (!result.stopped && result.pending > 0) {
      const confirmed = window.confirm(
        `${result.pending} file${result.pending === 1 ? " is" : "s are"} still uploading. ` +
          "Unmount anyway? Unfinished uploads resume the next time you mount this remote.",
      );
      if (confirmed) {
        result = await window.rcloneGui.unmountRemote(name, { force: true });
      }
    }
    mountStatus = result.status;
  } catch (error) {
    mountError = cleanIpcError(error, "Could not unmount the remote.");
  } finally {
    setBusy(false);
    renderRemoteList();
    renderMountPanel();
  }
}

async function selectRemote(name) {
  if (name !== selectedRemoteName) {
    mountError = "";
  }
  selectedRemoteName = name;
  renderRemoteList();
  showPanel("detail");
  renderMountPanel();
  window.RemoteServe?.show(name);
  remoteManager.detailName.textContent = name;
  paintAvatar(remoteManager.detailAvatar, name);
  replayAnimation(remoteManager.panelDetail, "is-swapping");
  remoteManager.detailType.textContent = "…";
  remoteManager.detailConfig.textContent = "Loading remote settings…";

  try {
    const entry = remoteEntries.find((item) => item.name === name);
    remoteManager.detailType.textContent = entry?.type || "unknown";
    updateReconnectAvailability();
    remoteManager.detailConfig.textContent = await window.rcloneGui.getRemoteRedacted(name);
  } catch (error) {
    remoteManager.detailConfig.textContent = error.message || "Could not load remote settings.";
  }
}

function sortProviders(items) {
  return [...items].sort((left, right) => {
    const leftPopular = POPULAR_PROVIDERS.indexOf(left.Name);
    const rightPopular = POPULAR_PROVIDERS.indexOf(right.Name);
    const leftRank = leftPopular === -1 ? Number.MAX_SAFE_INTEGER : leftPopular;
    const rightRank = rightPopular === -1 ? Number.MAX_SAFE_INTEGER : rightPopular;

    if (leftRank !== rightRank) {
      return leftRank - rightRank;
    }

    return left.Name.localeCompare(right.Name);
  });
}

function getFilteredProviders() {
  const query = remoteManager.providerSearch.value.trim().toLowerCase();
  const sorted = sortProviders(providers);

  if (!query) {
    return sorted;
  }

  return sorted.filter((provider) => {
    const haystack = `${provider.Name} ${provider.Description || ""}`.toLowerCase();
    return haystack.includes(query);
  });
}

function renderProviderOptions() {
  const filtered = getFilteredProviders();
  const current = remoteManager.providerSelect.value;
  remoteManager.providerSelect.innerHTML = "";

  for (const provider of filtered) {
    const option = document.createElement("option");
    option.value = provider.Name;
    option.textContent = POPULAR_PROVIDERS.includes(provider.Name)
      ? `${provider.Name} — ${provider.Description || "Popular provider"}`
      : `${provider.Name} — ${provider.Description || "Remote provider"}`;
    remoteManager.providerSelect.appendChild(option);
  }

  if (filtered.length === 0) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "No providers match your search";
    remoteManager.providerSelect.appendChild(option);
  } else if (filtered.some((provider) => provider.Name === current)) {
    remoteManager.providerSelect.value = current;
  } else {
    remoteManager.providerSelect.selectedIndex = 0;
  }

  renderProviderForm();
}

function getSelectedProvider() {
  const name = remoteManager.providerSelect.value;
  return providers.find((provider) => provider.Name === name) || null;
}

// Mirrors rclone's matchProvider(), with one UI tweak: options gated on a nested
// provider stay hidden until that provider is chosen (avoids triple password fields).
function matchProvider(providerConfig, nestedProvider) {
  if (!providerConfig) {
    return true;
  }

  if (!nestedProvider) {
    return false;
  }

  let config = String(providerConfig);
  let negate = false;
  if (config.startsWith("!")) {
    negate = true;
    config = config.slice(1);
  }

  const matched = config
    .split(",")
    .map((part) => part.trim())
    .filter(Boolean)
    .includes(nestedProvider);

  return negate ? !matched : matched;
}

function getNestedProviderValue(provider, previousValues = {}) {
  if (Object.prototype.hasOwnProperty.call(previousValues, "provider")) {
    return String(previousValues.provider || "");
  }

  const existing = remoteManager.providerForm.querySelector('[name="provider"]');
  if (existing?.value) {
    return existing.value;
  }

  const providerOption = (provider?.Options || []).find((option) => option.Name === "provider");
  if (!providerOption) {
    return "";
  }

  if (providerOption.DefaultStr) {
    return providerOption.DefaultStr;
  }

  const firstExample = (providerOption.Examples || []).find((example) => example.Value);
  return firstExample?.Value || "";
}

function endpointFromProviderHelp(provider, nestedProvider) {
  const providerOption = (provider?.Options || []).find((option) => option.Name === "provider");
  const example = (providerOption?.Examples || []).find((item) => item.Value === nestedProvider);
  if (!example?.Help) {
    return "";
  }

  const match = String(example.Help).match(/https?:\/\/[^\s,)]+/i);
  return match ? match[0] : "";
}

function shouldShowOption(option, nestedProvider) {
  if (!option || option.Hide) {
    return false;
  }

  if (option.Name === "type") {
    return false;
  }

  if (!matchProvider(option.Provider, nestedProvider)) {
    return false;
  }

  if (option.Required) {
    return true;
  }

  if (remoteManager.showAdvanced.checked) {
    return true;
  }

  return !option.Advanced;
}

function optionNeedsAuthorize(provider) {
  return provider?.Options?.some((option) => option.Name === "token") ?? false;
}

function hasToggleableAdvancedOptions(provider, nestedProvider) {
  return (provider?.Options || []).some((option) => {
    if (!option || option.Hide || option.Name === "type") {
      return false;
    }
    if (!option.Advanced || option.Required) {
      return false;
    }
    return matchProvider(option.Provider, nestedProvider);
  });
}

function createOptionInput(option, nestedProvider, previousValues) {
  let input;
  const previous = previousValues[option.Name];

  if (option.Examples?.length) {
    input = document.createElement("select");
    const examples = option.Examples.filter((example) => matchProvider(example.Provider, nestedProvider));

    if (!option.Exclusive && !option.Required) {
      const emptyOption = document.createElement("option");
      emptyOption.value = "";
      emptyOption.textContent = option.DefaultStr ? `Default (${option.DefaultStr})` : "Select…";
      input.appendChild(emptyOption);
    }

    for (const example of examples) {
      const exampleOption = document.createElement("option");
      exampleOption.value = example.Value;
      exampleOption.textContent = example.Help ? `${example.Value} — ${example.Help}` : example.Value;
      input.appendChild(exampleOption);
    }

    if (previous != null && previous !== "") {
      input.value = String(previous);
    } else if (option.Name === "provider" && nestedProvider) {
      input.value = nestedProvider;
    } else if (option.DefaultStr) {
      input.value = option.DefaultStr;
    } else if (option.Exclusive || option.Required) {
      const first = examples.find((example) => example.Value);
      if (first) {
        input.value = first.Value;
      }
    }
  } else if (option.Type === "bool") {
    input = document.createElement("input");
    input.type = "checkbox";
    if (typeof previous === "boolean") {
      input.checked = previous;
    } else {
      input.checked = option.Default === true || option.DefaultStr === "true";
    }
  } else {
    input = document.createElement("input");
    input.type = option.IsPassword ? "password" : option.Type === "string" && option.Name === "endpoint" ? "url" : "text";
    if (previous != null && previous !== "" && !option.IsPassword) {
      input.value = String(previous);
    } else if (option.DefaultStr && !option.IsPassword) {
      input.value = option.DefaultStr;
    } else if (option.DefaultStr) {
      input.placeholder = `Default: ${option.DefaultStr}`;
    }
  }

  input.id = `remote-option-${option.Name}`;
  input.name = option.Name;
  input.className = "remote-option-input";
  if (option.Name === "provider") {
    input.addEventListener("change", () => renderProviderForm());
  }

  return input;
}

function renderProviderForm() {
  const provider = getSelectedProvider();
  const previousValues = collectCreateOptions();
  remoteManager.providerForm.innerHTML = "";
  showCreateError("");

  if (!provider) {
    remoteManager.providerDescription.textContent = "";
    remoteManager.authorizeBtn.classList.add("hidden");
    remoteManager.showAdvanced?.closest(".remote-advanced-toggle")?.classList.add("hidden");
    return;
  }

  const nestedProvider = getNestedProviderValue(provider, previousValues);
  remoteManager.providerDescription.textContent = provider.Description || "";
  remoteManager.authorizeBtn.classList.toggle("hidden", !optionNeedsAuthorize(provider));

  const advancedToggle = remoteManager.showAdvanced?.closest(".remote-advanced-toggle");
  const showAdvancedToggle = hasToggleableAdvancedOptions(provider, nestedProvider);
  advancedToggle?.classList.toggle("hidden", !showAdvancedToggle);
  if (!showAdvancedToggle && remoteManager.showAdvanced) {
    remoteManager.showAdvanced.checked = false;
  }

  for (const option of provider.Options || []) {
    if (!shouldShowOption(option, nestedProvider)) {
      continue;
    }

    const field = document.createElement("label");
    field.className = "field remote-option-field";
    field.dataset.optionName = option.Name;

    const label = document.createElement("span");
    label.className = "field-label";
    label.textContent = option.Name.replace(/_/g, " ");
    if (option.Required) {
      label.textContent += " *";
    }
    field.appendChild(label);

    const input = createOptionInput(option, nestedProvider, previousValues);
    field.appendChild(input);

    if (option.Help) {
      const hint = document.createElement("span");
      hint.className = "remote-option-help";
      hint.textContent = option.Help.split("\n").join(" ");
      field.appendChild(hint);
    }

    remoteManager.providerForm.appendChild(field);
  }

  // Show the implied endpoint for providers like koofr/digistorage where rclone
  // fills it automatically and the endpoint option is hidden (Provider: other).
  const hasEndpointField = Boolean(remoteManager.providerForm.querySelector('[name="endpoint"]'));
  const impliedEndpoint = endpointFromProviderHelp(provider, nestedProvider);
  if (!hasEndpointField && impliedEndpoint) {
    const field = document.createElement("label");
    field.className = "field remote-option-field";
    field.dataset.optionName = "endpoint-display";

    const label = document.createElement("span");
    label.className = "field-label";
    label.textContent = "endpoint";
    field.appendChild(label);

    const input = document.createElement("input");
    input.type = "url";
    input.className = "remote-option-input";
    input.value = impliedEndpoint;
    input.disabled = true;
    input.readOnly = true;
    field.appendChild(input);

    const hint = document.createElement("span");
    hint.className = "remote-option-help";
    hint.textContent = "Filled automatically for this provider.";
    field.appendChild(hint);

    const providerField = remoteManager.providerForm.querySelector('[data-option-name="provider"]');
    if (providerField?.nextSibling) {
      remoteManager.providerForm.insertBefore(field, providerField.nextSibling);
    } else if (providerField) {
      providerField.after(field);
    } else {
      remoteManager.providerForm.prepend(field);
    }
  }
}

function collectCreateOptions() {
  const options = {};

  for (const field of remoteManager.providerForm.querySelectorAll(".remote-option-field")) {
    const name = field.dataset.optionName;
    const input = field.querySelector(".remote-option-input");
    if (!input || !name || input.disabled || name.endsWith("-display")) {
      continue;
    }

    if (input.type === "checkbox") {
      options[name] = input.checked;
      continue;
    }

    const value = input.value.trim();
    if (value) {
      options[name] = value;
    }
  }

  return options;
}

function fillTokenField(tokenText) {
  const tokenInput = remoteManager.providerForm.querySelector('[name="token"]');
  if (tokenInput && tokenText) {
    tokenInput.value = tokenText.trim();
  }
}

async function refreshRemotes({ keepSelection = true } = {}) {
  setBusy(true);

  try {
    remoteEntries = await window.rcloneGui.listRemoteEntries();
    const previous = keepSelection ? selectedRemoteName : null;
    renderRemoteList();

    if (previous && remoteEntries.some((entry) => entry.name === previous)) {
      await selectRemote(previous);
    } else if (remoteEntries.length === 0) {
      selectedRemoteName = null;
      showPanel("empty");
    } else if (!remoteManager.panelAdd.classList.contains("hidden")) {
      showPanel("add");
    } else if (!remoteManager.panelVault.classList.contains("hidden")) {
      showPanel("vault");
    } else {
      selectedRemoteName = null;
      showPanel("empty");
    }

    if (typeof onRemotesChanged === "function") {
      await onRemotesChanged(remoteEntries.map((entry) => entry.name));
    }
  } finally {
    setBusy(false);
  }
}

async function loadProviders() {
  providers = await window.rcloneGui.getConfigProviders();
  renderProviderOptions();
  updateReconnectAvailability();
}

function updateReconnectAvailability() {
  const entry = remoteEntries.find((item) => item.name === selectedRemoteName);
  const provider = providers.find((item) => item.Name === entry?.type);
  remoteManager.reconnectBtn.classList.toggle("hidden", !optionNeedsAuthorize(provider));
}

async function openRemoteManager({ onChanged, onBrowse } = {}) {
  if (!window.rcloneGui) {
    return;
  }

  onRemotesChanged = onChanged || null;
  onBrowseRemote = onBrowse || null;
  selectedRemoteName = null;
  showCreateError("");
  showPanel("empty");
  remoteManager.providerSearch.value = "";
  remoteManager.createName.value = "";
  remoteManager.showAdvanced.checked = false;
  remoteManager.dialog.classList.remove("hidden");
  remoteManager.dialog.setAttribute("aria-hidden", "false");
  remoteManager.list.classList.add("is-entering");
  setTimeout(() => remoteManager.list.classList.remove("is-entering"), 900);
  remoteManager.addBtn.focus();

  setBusy(true);
  try {
    const [configPath] = await Promise.all([
      window.rcloneGui.getConfigFilePath(),
      loadProviders(),
      refreshRemotes({ keepSelection: false }),
      refreshMountStatus(),
    ]);
    const cleanPath = String(configPath || "").replace(/^Configuration file is stored at:\s*/i, "").trim();
    remoteManager.configPath.textContent = cleanPath;
    remoteManager.configPath.title = cleanPath;
  } catch (error) {
    remoteManager.configPath.textContent = error.message || "Could not load rclone config.";
  } finally {
    setBusy(false);
  }
}

function closeRemoteManager() {
  remoteManager.dialog.classList.add("hidden");
  remoteManager.dialog.setAttribute("aria-hidden", "true");
  showCreateError("");
  selectedRemoteName = null;
  window.RemoteServe?.hide();
  window.VaultWizard?.reset();
}

function beginVault() {
  if (!window.VaultWizard) {
    return;
  }
  selectedRemoteName = null;
  renderRemoteList();
  showPanel("vault");
  window.VaultWizard.begin({
    container: remoteManager.panelVault,
    remotes: remoteEntries,
    onCancel: () => showPanel("empty"),
    onCreated: async (result) => {
      remoteEntries = result.entries;
      renderRemoteList();
      if (typeof onRemotesChanged === "function") {
        await onRemotesChanged(remoteEntries.map((entry) => entry.name));
      }
    },
    onOpen: (name) => {
      showPanel("detail");
      void selectRemote(name);
    },
    onBrowse: (name) => {
      closeRemoteManager();
      onBrowseRemote?.(name);
    },
  });
}

function beginAddRemote() {
  selectedRemoteName = null;
  renderRemoteList();
  showPanel("add");
  showCreateError("");
  remoteManager.createName.value = "";
  remoteManager.providerSearch.value = "";
  remoteManager.showAdvanced.checked = false;
  renderProviderOptions();
  remoteManager.createName.focus();
}

async function submitCreateRemote() {
  const provider = getSelectedProvider();
  const name = remoteManager.createName.value.trim();
  showCreateError("");

  if (!name) {
    showCreateError("Enter a name for the remote.");
    return;
  }

  if (!provider) {
    showCreateError("Select a provider.");
    return;
  }

  setBusy(true);
  try {
    remoteEntries = await window.rcloneGui.createRemote({
      name,
      type: provider.Name,
      options: collectCreateOptions(),
    });
    selectedRemoteName = name;
    renderRemoteList();
    showPanel("detail");
    await selectRemote(name);

    if (typeof onRemotesChanged === "function") {
      await onRemotesChanged(remoteEntries.map((entry) => entry.name));
    }
  } catch (error) {
    showCreateError(error.message || "Could not create remote.");
  } finally {
    setBusy(false);
  }
}

async function authorizeSelectedProvider() {
  const provider = getSelectedProvider();
  if (!provider) {
    showCreateError("Select a provider first.");
    return;
  }

  setBusy(true);
  showCreateError("");
  try {
    const token = await window.rcloneGui.authorizeProvider(provider.Name);
    fillTokenField(token);
  } catch (error) {
    showCreateError(error.message || "Authorization failed.");
  } finally {
    setBusy(false);
  }
}

async function deleteSelectedRemote() {
  if (!selectedRemoteName) {
    return;
  }

  if (getMount(selectedRemoteName)) {
    window.alert(`Unmount "${selectedRemoteName}" before deleting it.`);
    return;
  }

  if (window.RemoteServe?.isServing(selectedRemoteName)) {
    window.alert(`Stop serving "${selectedRemoteName}" before deleting it.`);
    return;
  }

  const confirmed = window.confirm(`Delete remote "${selectedRemoteName}"? This cannot be undone.`);
  if (!confirmed) {
    return;
  }

  setBusy(true);
  try {
    remoteEntries = await window.rcloneGui.deleteRemote(selectedRemoteName);
    selectedRemoteName = null;
    renderRemoteList();
    showPanel("empty");

    if (typeof onRemotesChanged === "function") {
      await onRemotesChanged(remoteEntries.map((entry) => entry.name));
    }
  } catch (error) {
    window.alert(error.message || "Could not delete remote.");
  } finally {
    setBusy(false);
  }
}

async function reconnectSelectedRemote() {
  if (!selectedRemoteName) {
    return;
  }

  setBusy(true);
  try {
    await window.rcloneGui.reconnectRemote(selectedRemoteName);
    await selectRemote(selectedRemoteName);
  } catch (error) {
    window.alert(cleanIpcError(error, "Could not reconnect remote."));
  } finally {
    setBusy(false);
  }
}

remoteManager.addBtn.addEventListener("click", beginAddRemote);
remoteManager.vaultBtn.addEventListener("click", beginVault);
remoteManager.refreshBtn.addEventListener("click", () => {
  void refreshRemotes();
});
remoteManager.createCancelBtn.addEventListener("click", () => {
  showCreateError("");
  if (selectedRemoteName) {
    void selectRemote(selectedRemoteName);
    return;
  }

  showPanel("empty");
});
remoteManager.createSubmitBtn.addEventListener("click", () => {
  void submitCreateRemote();
});
remoteManager.authorizeBtn.addEventListener("click", () => {
  void authorizeSelectedProvider();
});
remoteManager.deleteBtn.addEventListener("click", () => {
  void deleteSelectedRemote();
});
remoteManager.reconnectBtn.addEventListener("click", () => {
  void reconnectSelectedRemote();
});
remoteManager.openWizardBtn.addEventListener("click", () => {
  void window.rcloneGui.openRcloneConfig();
});
remoteManager.mountReconnectBtn.addEventListener("click", () => {
  void reconnectFromMountAlert();
});
remoteManager.mountBtn.addEventListener("click", () => {
  void mountSelectedRemote();
});
remoteManager.mountFolderPick.addEventListener("click", async () => {
  const picked = await window.rcloneGui.pickFolder();
  if (picked) {
    remoteManager.mountFolder.value = picked;
    if (selectedRemoteName) {
      mountFolders.set(selectedRemoteName, picked);
    }
  }
});
remoteManager.mountFolder.addEventListener("input", () => {
  if (selectedRemoteName) {
    mountFolders.set(selectedRemoteName, remoteManager.mountFolder.value);
  }
});
remoteManager.unmountBtn.addEventListener("click", () => {
  void unmountSelectedRemote();
});
remoteManager.mountOpenBtn.addEventListener("click", () => {
  if (!selectedRemoteName) {
    return;
  }
  window.rcloneGui.openMount(selectedRemoteName).catch((error) => {
    mountError = cleanIpcError(error, "Could not open the drive.");
    renderMountPanel();
  });
});
window.rcloneGui?.onMountsChanged?.((payload) => {
  const event = payload?.event;
  if (event?.type === "checked") {
    if (event.remote === selectedRemoteName) {
      mountChecking = false;
      renderMountPanel();
    }
    return;
  }
  if (event?.unexpected && event.remote === selectedRemoteName) {
    mountError = `${event.mountPoint} was unmounted unexpectedly: ${event.message}`;
  }
  if (!remoteManager.dialog.classList.contains("hidden")) {
    void refreshMountStatus();
  }
});
remoteManager.closeBtn.addEventListener("click", closeRemoteManager);
remoteManager.providerSearch.addEventListener("input", renderProviderOptions);
remoteManager.providerSelect.addEventListener("change", renderProviderForm);
remoteManager.showAdvanced.addEventListener("change", renderProviderForm);

for (const closer of remoteManager.dialog.querySelectorAll("[data-remote-manager-close]")) {
  closer.addEventListener("click", closeRemoteManager);
}

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !remoteManager.dialog.classList.contains("hidden")) {
    closeRemoteManager();
  }
});

window.RemoteManager = {
  open: openRemoteManager,
  close: closeRemoteManager,
};
