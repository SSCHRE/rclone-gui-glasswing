# CLAUDE.md

## Code style

- Never add code comments. Write self-explanatory code instead.

## Writing style

- Write commit messages, PR descriptions, docs and README text casually, like a human developer would. Keep it short and informal, and skip the polished AI tone.
- An occasional small typo in prose is fine. Never put typos in code, identifiers, config, file paths, commands or user-facing UI strings.
- Keep it all as HUMAN as POSSIBLE at ALL TIMES.

## Git

- Never add Co-Authored-By lines, "Generated with Claude Code" footers or any other mention of Claude or AI to commits, PRs, issues or docs.


## Development
- Use sonnet agents as much as possible